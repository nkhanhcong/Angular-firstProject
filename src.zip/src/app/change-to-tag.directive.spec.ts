import { ChangeToTagDirective } from './change-to-tag.directive';

describe('ChangeToTagDirective', () => {
  it('should create an instance', () => {
    const directive = new ChangeToTagDirective();
    expect(directive).toBeTruthy();
  });
});
