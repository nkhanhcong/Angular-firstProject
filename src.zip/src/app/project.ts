export class Project {
    numberProject: number;
    nameProject: string;
    customer: string;
    group: string;
    members: String[];
    status: string;
    startDate: string;
    endDate: string;
    constructor(numberProject: number, nameProject: string, customer: string, group: string, members: String[], status: string, startDate: string, endDate: string) {
        this.numberProject= numberProject;
        this.nameProject= nameProject;
        this.customer= customer;
        this.group= group;
        this.members= members;
        this.status= status;
        this.startDate= startDate;
        this.endDate= endDate;
    }
}

export class MarkProject {
    project: Project;
    selected: boolean;
}

export const status = ['New', 'In processing', 'Finished'];
export const groups = ['New', 'In processing', 'Finished'];