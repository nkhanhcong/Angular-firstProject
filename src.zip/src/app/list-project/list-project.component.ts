import { Component, OnInit } from '@angular/core';
import {ProjectService} from '../project.service';
import {Project, MarkProject} from '../project';
import { PageChangedEvent } from 'ngx-bootstrap';

@Component({
  selector: 'app-list-project',
  templateUrl: './list-project.component.html',
  styleUrls: ['./list-project.component.css']
})
export class ListProjectComponent implements OnInit {
  projects: Project[]=[];
  selectedProjects: Project[]=[];
  // selectedProject: Project;
  projectsInPage: Project[];
  test:String[]=[];
  saveProject: boolean;
  
  constructor(private projectService:ProjectService) { }

  getProjects() {
    return this.projectService.getProjects();
  }
  onSelectedProjects(event, project){
    if(event.target.checked){
      this.selectedProjects.push(project);
      // console.log(this.selectedProjects);
    }
    else{
      // console.log(project.numberProject)
      this.selectedProjects=this.selectedProjects.filter(projectInList=> projectInList.numberProject!= project.numberProject);  
    
    //  console.log(this.selectedProjects)
    }
    
  }

  deleteSingleProject(project:Project){
    this.projectsInPage=this.projectService.deleteProject(project).subscribe();
  }
  numberProjects(){
    return this.projects.length;
  }

  isSelected(project:Project){
    return this.selectedProjects.filter(projectInList=> projectInList.numberProject==project.numberProject).length>0;
  }

  deleteProject(project:Project){
    this.
  }
  ngOnInit() {
    this.getProjects().subscribe((projects) => {
        this.projects = projects;
        this.projectsInPage =  projects.slice(0,5);
    });
    
  }

  pageChange(event:PageChangedEvent): void{    
    const startItem = (event.page - 1) * event.itemsPerPage;
    const endItem = event.page * event.itemsPerPage;
    this.projectsInPage= this.projects.slice(startItem,endItem);
   
  }

}
