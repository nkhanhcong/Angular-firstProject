import { Directive, ElementRef, Input, HostListener } from '@angular/core';
import { Key } from 'protractor';

@Directive({
  selector: '[appChangeToTag]'
})
export class ChangeToTagDirective {
  @Input('appChangeToTag') nameMember:String;


  constructor(el:ElementRef) {
    el.nativeElement.style.backgroundColor='yellow';
   }


   @HostListener('mouseenter') onKeyEnter(){
     console.log(this.nameMember);
   }

}
