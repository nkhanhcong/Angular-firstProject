import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Input, OnChanges } from '@angular/core';
import { ReactiveFormsModule, FormGroup, FormControl} from '@angular/forms'

import { AppComponent } from './app.component';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { AlertModule, PaginationModule } from 'ngx-bootstrap';
import { ListProjectComponent } from './list-project/list-project.component';

import { DataProjectService } from './data-project.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {CommonModule} from '@angular/common';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';

// service
import { ProjectService } from './project.service';
import { AppRoutingModule } from './app-routing.module'

// ag-grid
import { AgGridModule } from 'ag-grid-angular';

import {ChipsModule} from 'primeng/chips';

import {ButtonModule} from 'primeng/button';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatNativeDateModule,MatDatepickerModule, MatMenuModule,
  MatToolbarModule,
  MatIconModule,
  MatCardModule,
  MatSidenavModule,
  MatFormFieldModule,
  MatInputModule,
  MatTooltipModule} from '@angular/material';
import {MatButtonModule, MatCheckboxModule} from '@angular/material';
import { CreateProjectComponent } from './create-project/create-project.component';

// prime ng
import {CalendarModule} from 'primeng/calendar';
import { ChangeToTagDirective } from './change-to-tag.directive';
import { FieldErrorDisplayComponent } from './field-error-display/field-error-display.component'

const materialModules = [
  MatNativeDateModule,
  MatDatepickerModule,
  MatButtonModule,
  MatMenuModule,
  MatToolbarModule,
  MatIconModule,
  MatCardModule,
  MatSidenavModule,
  MatFormFieldModule,
  MatInputModule,
  MatTooltipModule
];

@NgModule({
  declarations: [
    AppComponent,
    ListProjectComponent,
    CreateProjectComponent,
    ChangeToTagDirective,
    FieldErrorDisplayComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    HttpClientInMemoryWebApiModule.forRoot(
      DataProjectService, { dataEncapsulation: false }
    ),
    TooltipModule.forRoot(),
    AlertModule.forRoot(),
    AppRoutingModule,
    AgGridModule.withComponents([]),
    AccordionModule.forRoot(),
    PaginationModule.forRoot(),
    BrowserAnimationsModule,
    ReactiveFormsModule,
    ...materialModules,
    FormsModule,
    ChipsModule,
    ButtonModule,
    CommonModule,
    CalendarModule
  ],
  providers: [ProjectService],
  bootstrap: [AppComponent]
})
export class AppModule { }
