import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {ListProjectComponent} from './list-project/list-project.component';
import {CreateProjectComponent} from './create-project/create-project.component'

const routes: Routes=[
  {path:'', redirectTo:'/listProject', pathMatch:'full'},
  {path:'listProject', component:ListProjectComponent},
  {path: 'createProject', component:CreateProjectComponent}
]

@NgModule({
  imports:[RouterModule.forRoot(routes)],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
