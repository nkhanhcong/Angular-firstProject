import { TestBed, inject } from '@angular/core/testing';

import { DataProjectService } from './data-project.service';

describe('DataProjectService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DataProjectService]
    });
  });

  it('should be created', inject([DataProjectService], (service: DataProjectService) => {
    expect(service).toBeTruthy();
  }));
});
