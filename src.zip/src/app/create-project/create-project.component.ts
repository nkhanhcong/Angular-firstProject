import { Component, OnInit, group } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Project, status, groups } from '../project'
import { DatePipe, JsonPipe } from '@angular/common';
import { start } from 'repl';
import { ProjectService } from '../project.service';

@Component({
  selector: 'app-create-project',
  templateUrl: './create-project.component.html',
  styleUrls: ['./create-project.component.css']
})
export class CreateProjectComponent implements OnInit {
  projectForm: FormGroup;
  project: Project;
  status = status;
  groups = groups;
  date3: Date;
  formSubmitAttempt: boolean;
  pipe = new DatePipe('en-US');


  constructor(private fb: FormBuilder, private projectService:ProjectService) {
    this.createForm();

  }

  validateAllFormFields(formGroup: FormGroup){
    Object.keys(formGroup.controls).forEach(
      field=> {
        const formControl= formGroup.get(field);
        formControl.markAsTouched({onlySelf:true});
       
      }
    )
  }

  createProject() {
    if(this.projectForm.valid){
      
      const numberProject= +this.numberProject.value;
      const nameProject= this.nameProject.value;
      const customer= this.customer.value;
      const group= this.group.value;
      const member= this.member.value;
      const status= this.statusChoose.value;
      const startDate= this.startDate.value;
      const endDate= this.endDate.value; 
      // console.log(this.projectForm.getRawValue())
      // console.log(numberProject);
      this.project= new Project(numberProject,nameProject,customer,group,member,status,startDate,endDate);
      this.projectService.addProject(this.project).subscribe( 
          //do some stuff
        // error=>{
        // console.log(error);
        // throw error;
      // }
      );

      this.projectService.getProjects().subscribe(project=> console.log(project))

    }
    else{
      this.validateAllFormFields(this.projectForm);
    }
   
  }

  onKeyUp(event) {
    // console.log(event.key==',');

  }

  createForm() {
    this.projectForm = this.fb.group({
      numberProject: this.fb.control('', [Validators.required]),
      nameProject: this.fb.control('', [Validators.required]),
      customer: this.fb.control('', [Validators.required]),
      group: this.groups[0],
      member: this.fb.control('',[]),
      status: this.status[0],
      startDate: this.fb.control('', [Validators.required]),
      endDate: this.fb.control('',[])
    });
  }

  isFieldValid(field: string) {
    return !this.projectForm.get(field).valid && this.projectForm.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    }
  }


  get numberProject(){
    return this.projectForm.get('numberProject');
  }
  get nameProject(){
    return this.projectForm.get('nameProject');
  }
  get customer(){
    return this.projectForm.get('customer');
  }
  get group(){
    return this.projectForm.get('group');
  }
  get statusChoose(){
    return this.projectForm.get('status');
  }
  get member(){
    return this.projectForm.get('member');
  }
  get startDate(){
    return this.projectForm.get('startDate');
  }
  get endDate(){
    return this.projectForm.get('endDate');
  }

  ngOnInit() {
  }

}
