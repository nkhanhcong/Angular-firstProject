import { Injectable, ErrorHandler } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';

import { Observable} from 'rxjs';
import {of} from 'rxjs/observable/of';
import {Project} from './project';
import { catchError, map, tap } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class ProjectService {
  private projectsUrl= 'api/projects';
  
  constructor(private httpClient:HttpClient) { }
  
  getProjects():Observable<Project[]>{
    return this.httpClient.get<Project[]>(this.projectsUrl);
  }
  
  addProject(project:Project):Observable<Project>{
    // console.log(project);
    return this.httpClient.post<Project>(this.projectsUrl,project,httpOptions).pipe(
      tap(_=> this.log(`add project`)),
      catchError(this.handleError<any>('add Project error',[]))
    )
  }

  deleteProject(project:Project| number):Observable<Project>{
    
    // const id= 
    return ;
  }

  private handleError<T>(operation='operation', result?:T){
    return (error: any):Observable<T>=>{
      console.log(error);
      return of(result as T);
    };
  }

  

  private log(message: string){
    console.log(message);
  }
  getProjectsPage(startItem:Number, endItem:Number):Observable<Project[]>{
    return this.httpClient.get<Project[]>(this.projectsUrl)
  }
}
