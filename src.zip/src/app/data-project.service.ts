import { InMemoryDbService } from 'angular-in-memory-web-api';

export class DataProjectService implements InMemoryDbService {
  createDb() {
    const projects = [
      {id:1, numberProject: 1, nameProject: "project 1", customer: "A", group: "New", members: ["A", "B"], status: "New", startDate: "22/04/2017", endDate: "29/06/2017" },
      {id:2, numberProject: 2, nameProject: "project 2", customer: "B", group: "New", members: ["A", "M"], status: "New", startDate: "22/04/2018", endDate: "29/06/2019" },
      {id:3, numberProject: 3, nameProject: "project 3", customer: "C", group: "New", members: ["A", "B", "C"], status: "In progress", startDate: "22/01/2017", endDate: "29/03/2017" },
      {id:4, numberProject: 4, nameProject: "project 4", customer: "D", group: "New", members: ["A", "B", "H"], status: "New", startDate: "02/04/2017", endDate: "29/07/2017" },
      {id:5, numberProject: 5, nameProject: "project 1", customer: "A", group: "New", members: ["A", "B"], status: "New", startDate: "22/04/2017", endDate: "29/06/2017" },
      {id:6, numberProject: 6, nameProject: "project 2", customer: "B", group: "New", members: ["A", "M"], status: "New", startDate: "22/04/2018", endDate: "29/06/2019" },
      {id:7, numberProject: 7, nameProject: "project 3", customer: "C", group: "New", members: ["A", "B", "C"], status: "In progress", startDate: "22/01/2017", endDate: "29/03/2017" },
      {id:8, numberProject: 8, nameProject: "project 1", customer: "A", group: "New", members: ["A", "B"], status: "New", startDate: "22/04/2017", endDate: "29/06/2017" },
      {id:9, numberProject: 9, nameProject: "project 2", customer: "B", group: "New", members: ["A", "M"], status: "New", startDate: "22/04/2018", endDate: "29/06/2019" },
      {id:10, numberProject: 10, nameProject: "project 3", customer: "C", group: "New", members: ["A", "B", "C"], status: "In progress", startDate: "22/01/2017", endDate: "29/03/2017" },
      {id:11, numberProject: 11, nameProject: "project 1", customer: "A", group: "New", members: ["A", "B"], status: "New", startDate: "22/04/2017", endDate: "29/06/2017" },
      {id:12, numberProject: 12, nameProject: "project 2", customer: "B", group: "New", members: ["A", "M"], status: "New", startDate: "22/04/2018", endDate: "29/06/2019" },
      {id:13, numberProject: 13, nameProject: "project 3", customer: "C", group: "New", members: ["A", "B", "C"], status: "In progress", startDate: "22/01/2017", endDate: "29/03/2017" },
      {id:14, numberProject: 14, nameProject: "project 1", customer: "A", group: "New", members: ["A", "B"], status: "New", startDate: "22/04/2017", endDate: "29/06/2017" },
      {id:15, numberProject: 15, nameProject: "project 2", customer: "B", group: "New", members: ["A", "M"], status: "New", startDate: "22/04/2018", endDate: "29/06/2019" },
      {id:16, numberProject: 16, nameProject: "project 3", customer: "C", group: "New", members: ["A", "B", "C"], status: "In progress", startDate: "22/01/2017", endDate: "29/03/2017" },
      {id:17, numberProject: 17, nameProject: "project 1", customer: "A", group: "New", members: ["A", "B"], status: "New", startDate: "22/04/2017", endDate: "29/06/2017" },
      {id:18, numberProject: 18, nameProject: "project 2", customer: "B", group: "New", members: ["A", "M"], status: "New", startDate: "22/04/2018", endDate: "29/06/2019" },
      {id:19, numberProject: 19, nameProject: "project 3", customer: "C", group: "New", members: ["A", "B", "C"], status: "In progress", startDate: "22/01/2017", endDate: "29/03/2017" },
      {id:20, numberProject: 20, nameProject: "project 1", customer: "A", group: "New", members: ["A", "B"], status: "New", startDate: "22/04/2017", endDate: "29/06/2017" },
      {id:21, numberProject: 21, nameProject: "project 2", customer: "B", group: "New", members: ["A", "M"], status: "New", startDate: "22/04/2018", endDate: "29/06/2019" },
      {id:22, numberProject: 22, nameProject: "project 3", customer: "C", group: "New", members: ["A", "B", "C"], status: "In progress", startDate: "22/01/2017", endDate: "29/03/2017" }

  
    ]
    return {projects};
  }
}
